//
//  NewsDataTableViewCell.swift
//  iOSTask
//
//  Created by Nikol Vasileva on 14.04.23.
//

import UIKit

class NewsDataTableViewCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var sourceNameLabel: UILabel!
    @IBOutlet weak var publishedAtLabel: UILabel!
   
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setupCell(with data: Article){
        self.titleLabel.text = String(data.title)
        self.authorLabel.text = "Author: \(String(data.author))"
        self.sourceNameLabel.text = data.source?.name
        self.publishedAtLabel.text = "Published: \(String(data.publishedAt))"
        
    }

}
